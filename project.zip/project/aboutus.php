<!DOCTYPE html>
<html lang="en-US">
<head>
<meta charset="UTF-8" />
<meta name="author" content="Lavanya Goluguri" />
<meta name="description" content="REAL ESTATE" />
<meta name="keywords" content="Give your key words for SEO" />

<title>HOUSING SYSTEM</title>
<!-- ADDING CSS HERE -->
<link rel="stylesheet" type="text/css" href="assets/style.css" />
</head>

<body>
<!-- Header starts here -->
<header class="header">
<div class="wrapper">
<h1>HOUSING SYSTEM</h1>
</div>
</header>
<!--Header ends here -->
<!-- Menu starts here -->
<nav class="menu">
<div class="wrapper">
<ul>
<a href="index.html"><li>HOME</li></a>
<a href="#"><li>Houses</li></a>
<a href="contact.html"><li>Contact Us</li></a>
<a href="login.html"><li>Log In</li></a>

<br/>


</ul>
</div>
<!--Menu ends here -->
<!-- Main Body starts here -->
</nav>
<div class="main">
<div class="wrapper">
<div class="book-house">
<h3>About Us </h3>
<!--About Us here \-->

   <p>
   The Hampton is a wonderfully flexible plan with a large task room ideal for hobby or home office space, and a ground floor flex room that can be used as a formal living room or study. The upstairs loft is perfect for a media room. The beautiful kitchen features a large center island with breakfast bar for quick, casual meals. Enhance your living space and add a sunroom for a comfortable retreat filled with natural light.
   
<br/>Type:Single Family<br />
Year built:2019<br />
Parking:2 spaces<br />
Lot: 5000 sqft <br />
Price/sqft:$60<br/>
   </p>

</div>





</div>
 </div>
 <!--Main body ends here -->
<!--Footer starts here -->
<br /><br /><br /><br /><br /><br /><br />
<br /><br /><br /><br /><br /><br /><br />
<footer  class="footer">
<div class="wrapper">
<p>&copy; <a href="#">HOUSING SYSTEM</a>. All rights reserved 2019. </p>
</div>
</footer>
<!--Footer ends here -->

  </body>
</html>