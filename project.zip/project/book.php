<!DOCTYPE html>
<html lang="en-US">
<head>
<meta charset="UTF-8" />
<meta name="author" content="Lavanya Goluguri" />
<meta name="description" content="HOUSING SYSTEM" />
<meta name="keywords" content="Give your key words for SEO" />

<title>HOUSING SYSTEM</title>
<!-- ADDING CSS HERE -->
<link rel="stylesheet" type="text/css" href="assets/style.css" />
</head>

<body>
<!-- Header starts here -->
<header class="header">
<div class="wrapper">
<h1>HOUSING SYSTEM</h1>
</div>
</header>
<!--Header ends here -->
<!-- Menu starts here -->
<nav class="menu">
<div class="wrapper">
<ul>
<a href="index.html"><li>HOME</li></a>
<a href="about.html"><li>About Us</li></a>
<a href="#"><li>Houses</li></a>
<a href="contact.html"><li>Contact Us</li></a>
<a href="login.html"><li>Log In</li></a>
</ul>
</div>
<!--Menu ends here -->
<!-- Main Body starts here -->
</nav>
<div class="main">
<div class="wrapper">
<div class="book-house">
<h3>Single Family Hampton Home</h3>
<!-- House details here-->
 <img src = "C:\Users\lavan\Desktop\SE\project\images\house1.jpg" />
  
   <span class="house-added">Added on:09/15/2019</span><br/>
   <span class="house-location">Locaton: Burlington, NC</span><br/>
   <span class="house-price">Price $275000</span>
   <p>
   The Hampton is a wonderfully flexible plan with a large task room ideal for hobby or home office space, and a ground floor flex room that can be used as a formal living room or study. The upstairs loft is perfect for a media room. The beautiful kitchen features a large center island with breakfast bar for quick, casual meals. Enhance your living space and add a sunroom for a comfortable retreat filled with natural light.
   
<br/>Type:Single Family<br />
Year built:2019<br />
Parking:2 spaces<br />
Lot: 5000 sqft <br />
Price/sqft:$60<br/>
   </p>

</div>

<!-- Client booking details entry-->
<div class="booking-details">
<h3> Your Booking Details</h3>
<form>
<span class="name">First Name</span>
<input type="text" name="first_name" placeholder="First Name Please" /> <br />

<span class="name">Last Name</span>
<input type="text" name="last_name" placeholder="Last Name Please" /> <br />

<span class="name">E-mail</span>
<input type="email" name="email" placeholder="Email please" /> <br />

<span class="name">Contact no</span>
<input type="tel" name="contact" placeholder="contact number please" /> <br />

<span class="name">Address</span>
<textarea name="address" placeholder="Your Address Please"></textarea></textarea> <br />

<input type="submit" name="submit" placeholder="BOOK NOW"/>
<input type="reset" name="reset" placeholder="RESET" />

</form>
</div>



</div>
 </div>
 <!--Main body ends here -->
<!--Footer starts here -->
<footer  class="footer">
<div class="wrapper">
<p>&copy; <a href="#">HOUSING SYSTEM</a>. All rights reserved 2019. </p>
</div>
</footer>
<!--Footer ends here -->

  </body>
</html>